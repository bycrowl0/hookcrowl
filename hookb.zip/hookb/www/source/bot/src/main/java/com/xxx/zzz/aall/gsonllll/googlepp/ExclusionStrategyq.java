

package com.xxx.zzz.aall.gsonllll.googlepp;


public interface ExclusionStrategyq {


  public boolean shouldSkipField(FieldAttributesq f);


  public boolean shouldSkipClass(Class<?> clazz);
}
