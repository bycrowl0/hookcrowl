package com.xxx.zzz.aall.ioppp.socketlll.utf8nnn;

import java.io.IOException;

public class UTF8Exceptionz extends IOException {

    public UTF8Exceptionz() {
        super();
    }

    public UTF8Exceptionz(String message) {
        super(message);
    }

    public UTF8Exceptionz(String message, Throwable cause) {
        super(message, cause);
    }

    public UTF8Exceptionz(Throwable cause) {
        super(cause);
    }
}
