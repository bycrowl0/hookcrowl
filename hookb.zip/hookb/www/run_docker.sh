#!/bin/bash

sudo docker run -d -p 8082:80 -it builder2
