#!/usr/bin/env python3

from .random_manifest import RandomManifest
