---
name: "\U0001F4AC Question"
about: "Ask a general question about Obfuscapk"
title: ""
labels: "question"
assignees: ""
---

<!--
Thank you for your interest in Obfuscapk.

You can use this issue for anything other than bug reports and feature requests. Please provide as much information as needed to help us answer your question(s). Please make sure to also check the FAQ at https://github.com/ClaudiuGeorgiu/Obfuscapk/blob/master/docs/FAQ.md as you may find an answer for the most common questions.

NOTE:
    * if you're including code snippets/logs, please format them properly (see https://help.github.com/github/writing-on-github/basic-writing-and-formatting-syntax#quoting-code);
    * blocks starting with `< !--` and ending with `-- >` (without spaces) are treated as comments and won't be rendered, so please don't edit the text inside these blocks since your modifications won't be visible. If you want the text to be visible, remove `< !--` and `-- >` tags.
-->
